--
-- PostgreSQL database dump
--

\restrict umwSdpl2RxdTJwZEwlWEHpqJVrmg6CxYd5eOHagXKGHTEy5zjIcMXEd88RUvrDy

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6 (Debian 17.6-2.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', NEW.raw_user_meta_data->>'full_name', '')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.handle_new_user() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    name text,
    provider_instance_id text,
    status text,
    provider text,
    connection_status text,
    provider_token text
);


ALTER TABLE public.channels OWNER TO postgres;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    tenant_id uuid,
    phone text,
    name text,
    remote_jid text,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: COLUMN contacts.is_active; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.contacts.is_active IS 'Indica se o contato esta ativo no workspace';


--
-- Name: conversation_tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversation_tags (
    conversation_id uuid NOT NULL,
    tag_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.conversation_tags OWNER TO postgres;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    tenant_id uuid,
    channel_id uuid,
    contact_id uuid,
    last_message_preview text
);


ALTER TABLE public.conversations OWNER TO postgres;

--
-- Name: crm_cards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_cards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    stage_id uuid,
    conversation_id uuid,
    tenant_id uuid,
    "position" integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crm_cards OWNER TO postgres;

--
-- Name: crm_funnels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_funnels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid,
    tenant_id uuid,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crm_funnels OWNER TO postgres;

--
-- Name: crm_stages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.crm_stages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    funnel_id uuid,
    tenant_id uuid,
    name text NOT NULL,
    "position" integer NOT NULL,
    color text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.crm_stages OWNER TO postgres;

--
-- Name: media_files; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    message_id text NOT NULL,
    media_id text NOT NULL,
    mime_type text NOT NULL,
    storage_url text,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT media_files_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'uploaded'::text, 'failed'::text])))
);


ALTER TABLE public.media_files OWNER TO postgres;

--
-- Name: message_templates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    language text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    components jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.message_templates OWNER TO postgres;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    conversation_id uuid,
    wa_message_id text,
    direction text,
    type text,
    content text,
    sender_name text
);


ALTER TABLE public.messages OWNER TO postgres;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    name text,
    email text,
    phone text,
    created_at timestamp with time zone DEFAULT now(),
    avatar_url text
);


ALTER TABLE public.profiles OWNER TO postgres;

--
-- Name: quick_replies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.quick_replies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    shortcut text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.quick_replies OWNER TO postgres;

--
-- Name: routing_config; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.routing_config (
    workspace_id uuid NOT NULL,
    tenant_id uuid,
    round_robin_enabled boolean DEFAULT false,
    retention_days integer DEFAULT 7,
    tag_routing jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.routing_config OWNER TO postgres;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tags (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    workspace_id uuid NOT NULL,
    name text NOT NULL,
    color text DEFAULT '#3b82f6'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tags OWNER TO postgres;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- Name: user_workspaces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_workspaces (
    user_id uuid NOT NULL,
    workspace_id uuid NOT NULL,
    role text,
    status text DEFAULT 'active'::text
);


ALTER TABLE public.user_workspaces OWNER TO postgres;

--
-- Name: whatsapp_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.whatsapp_sessions (
    instance_id text NOT NULL,
    key_id text NOT NULL,
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at timestamp with time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


ALTER TABLE public.whatsapp_sessions OWNER TO postgres;

--
-- Name: workspaces; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.workspaces (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name text,
    owner_id uuid,
    stripe_customer_id text,
    stripe_subscription_id text,
    plan text,
    subscription_status text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.workspaces OWNER TO postgres;

--
-- Data for Name: channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.channels (id, workspace_id, name, provider_instance_id, status, provider, connection_status, provider_token) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id, workspace_id, tenant_id, phone, name, remote_jid, is_active) FROM stdin;
\.


--
-- Data for Name: conversation_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversation_tags (conversation_id, tag_id, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.conversations (id, workspace_id, tenant_id, channel_id, contact_id, last_message_preview) FROM stdin;
\.


--
-- Data for Name: crm_cards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_cards (id, stage_id, conversation_id, tenant_id, "position", created_at) FROM stdin;
\.


--
-- Data for Name: crm_funnels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_funnels (id, workspace_id, tenant_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: crm_stages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.crm_stages (id, funnel_id, tenant_id, name, "position", color, created_at) FROM stdin;
\.


--
-- Data for Name: media_files; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_files (id, tenant_id, message_id, media_id, mime_type, storage_url, status, attempts, error, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: message_templates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message_templates (id, workspace_id, name, category, language, status, components, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.messages (id, tenant_id, conversation_id, wa_message_id, direction, type, content, sender_name) FROM stdin;
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.profiles (id, name, email, phone, created_at, avatar_url) FROM stdin;
2f97eb69-0b9b-4638-9c4b-fd27ab7311c0	C Amorim de Santana	mcmoriam@gmail.com	\N	2026-06-14 02:10:38.41714+00	\N
\.


--
-- Data for Name: quick_replies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.quick_replies (id, workspace_id, shortcut, content, created_at) FROM stdin;
\.


--
-- Data for Name: routing_config; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.routing_config (workspace_id, tenant_id, round_robin_enabled, retention_days, tag_routing, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tags (id, workspace_id, name, color, created_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (id, name) FROM stdin;
\.


--
-- Data for Name: user_workspaces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_workspaces (user_id, workspace_id, role, status) FROM stdin;
\.


--
-- Data for Name: whatsapp_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.whatsapp_sessions (instance_id, key_id, data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workspaces; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.workspaces (id, tenant_id, name, owner_id, stripe_customer_id, stripe_subscription_id, plan, subscription_status, created_at) FROM stdin;
2e5a4ba9-5a4a-42d7-816b-a3c0c9482998	\N	Agência Plus	2f97eb69-0b9b-4638-9c4b-fd27ab7311c0	\N	\N	\N	\N	2026-06-14 02:12:27.951163+00
\.


--
-- Name: channels channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversation_tags conversation_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_tags
    ADD CONSTRAINT conversation_tags_pkey PRIMARY KEY (conversation_id, tag_id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: crm_cards crm_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_cards
    ADD CONSTRAINT crm_cards_pkey PRIMARY KEY (id);


--
-- Name: crm_funnels crm_funnels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_funnels
    ADD CONSTRAINT crm_funnels_pkey PRIMARY KEY (id);


--
-- Name: crm_stages crm_stages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_stages
    ADD CONSTRAINT crm_stages_pkey PRIMARY KEY (id);


--
-- Name: media_files media_files_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_files
    ADD CONSTRAINT media_files_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_pkey PRIMARY KEY (id);


--
-- Name: message_templates message_templates_workspace_id_name_language_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_workspace_id_name_language_key UNIQUE (workspace_id, name, language);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: quick_replies quick_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quick_replies
    ADD CONSTRAINT quick_replies_pkey PRIMARY KEY (id);


--
-- Name: quick_replies quick_replies_workspace_id_shortcut_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quick_replies
    ADD CONSTRAINT quick_replies_workspace_id_shortcut_key UNIQUE (workspace_id, shortcut);


--
-- Name: routing_config routing_config_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing_config
    ADD CONSTRAINT routing_config_pkey PRIMARY KEY (workspace_id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_workspace_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_workspace_id_name_key UNIQUE (workspace_id, name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_workspaces user_workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_workspaces
    ADD CONSTRAINT user_workspaces_pkey PRIMARY KEY (user_id, workspace_id);


--
-- Name: whatsapp_sessions whatsapp_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.whatsapp_sessions
    ADD CONSTRAINT whatsapp_sessions_pkey PRIMARY KEY (instance_id, key_id);


--
-- Name: workspaces workspaces_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_pkey PRIMARY KEY (id);


--
-- Name: idx_conversation_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_conversation_tags_tag_id ON public.conversation_tags USING btree (tag_id);


--
-- Name: idx_media_files_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_status ON public.media_files USING btree (status) WHERE (status = 'pending'::text);


--
-- Name: idx_media_files_wa_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_media_files_wa_id ON public.media_files USING btree (message_id);


--
-- Name: idx_quick_replies_workspace_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_quick_replies_workspace_id ON public.quick_replies USING btree (workspace_id);


--
-- Name: idx_tags_workspace_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tags_workspace_id ON public.tags USING btree (workspace_id);


--
-- Name: channels channels_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channels
    ADD CONSTRAINT channels_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: contacts contacts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: contacts contacts_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: conversation_tags conversation_tags_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_tags
    ADD CONSTRAINT conversation_tags_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: conversation_tags conversation_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversation_tags
    ADD CONSTRAINT conversation_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: conversations conversations_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channels(id);


--
-- Name: conversations conversations_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: conversations conversations_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: conversations conversations_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: crm_cards crm_cards_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_cards
    ADD CONSTRAINT crm_cards_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: crm_cards crm_cards_stage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_cards
    ADD CONSTRAINT crm_cards_stage_id_fkey FOREIGN KEY (stage_id) REFERENCES public.crm_stages(id) ON DELETE CASCADE;


--
-- Name: crm_cards crm_cards_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_cards
    ADD CONSTRAINT crm_cards_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: crm_funnels crm_funnels_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_funnels
    ADD CONSTRAINT crm_funnels_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: crm_funnels crm_funnels_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_funnels
    ADD CONSTRAINT crm_funnels_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: crm_stages crm_stages_funnel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_stages
    ADD CONSTRAINT crm_stages_funnel_id_fkey FOREIGN KEY (funnel_id) REFERENCES public.crm_funnels(id) ON DELETE CASCADE;


--
-- Name: crm_stages crm_stages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.crm_stages
    ADD CONSTRAINT crm_stages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: message_templates message_templates_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message_templates
    ADD CONSTRAINT message_templates_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: messages messages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: quick_replies quick_replies_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.quick_replies
    ADD CONSTRAINT quick_replies_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: routing_config routing_config_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing_config
    ADD CONSTRAINT routing_config_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: routing_config routing_config_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.routing_config
    ADD CONSTRAINT routing_config_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: tags tags_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id) ON DELETE CASCADE;


--
-- Name: user_workspaces user_workspaces_workspace_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_workspaces
    ADD CONSTRAINT user_workspaces_workspace_id_fkey FOREIGN KEY (workspace_id) REFERENCES public.workspaces(id);


--
-- Name: workspaces workspaces_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.profiles(id);


--
-- Name: workspaces workspaces_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.workspaces
    ADD CONSTRAINT workspaces_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: routing_config Admins can insert routing config; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can insert routing config" ON public.routing_config FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = routing_config.workspace_id) AND (user_workspaces.user_id = auth.uid()) AND (user_workspaces.role = ANY (ARRAY['owner'::text, 'admin'::text]))))));


--
-- Name: quick_replies Admins can manage quick replies; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage quick replies" ON public.quick_replies USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = quick_replies.workspace_id) AND (user_workspaces.user_id = auth.uid()) AND (user_workspaces.role = ANY (ARRAY['owner'::text, 'admin'::text]))))));


--
-- Name: tags Admins can manage tags; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can manage tags" ON public.tags USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = tags.workspace_id) AND (user_workspaces.user_id = auth.uid()) AND (user_workspaces.role = ANY (ARRAY['owner'::text, 'admin'::text]))))));


--
-- Name: routing_config Admins can update routing config; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can update routing config" ON public.routing_config FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = routing_config.workspace_id) AND (user_workspaces.user_id = auth.uid()) AND (user_workspaces.role = ANY (ARRAY['owner'::text, 'admin'::text]))))));


--
-- Name: conversation_tags Agents can manage conversation tags; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Agents can manage conversation tags" ON public.conversation_tags USING ((EXISTS ( SELECT 1
   FROM (public.conversations
     JOIN public.user_workspaces ON ((user_workspaces.workspace_id = conversations.workspace_id)))
  WHERE ((conversations.id = conversation_tags.conversation_id) AND (user_workspaces.user_id = auth.uid())))));


--
-- Name: whatsapp_sessions Allow Service Role fully on whatsapp_sessions; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow Service Role fully on whatsapp_sessions" ON public.whatsapp_sessions USING (true) WITH CHECK (true);


--
-- Name: media_files Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON public.media_files FOR SELECT USING (true);


--
-- Name: message_templates Users can delete templates of their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can delete templates of their workspaces" ON public.message_templates FOR DELETE USING ((workspace_id IN ( SELECT user_workspaces.workspace_id
   FROM public.user_workspaces
  WHERE (user_workspaces.user_id = auth.uid()))));


--
-- Name: message_templates Users can insert templates to their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can insert templates to their workspaces" ON public.message_templates FOR INSERT WITH CHECK ((workspace_id IN ( SELECT user_workspaces.workspace_id
   FROM public.user_workspaces
  WHERE (user_workspaces.user_id = auth.uid()))));


--
-- Name: message_templates Users can update templates of their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can update templates of their workspaces" ON public.message_templates FOR UPDATE USING ((workspace_id IN ( SELECT user_workspaces.workspace_id
   FROM public.user_workspaces
  WHERE (user_workspaces.user_id = auth.uid()))));


--
-- Name: conversation_tags Users can view conversation tags for their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view conversation tags for their workspaces" ON public.conversation_tags FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.conversations
     JOIN public.user_workspaces ON ((user_workspaces.workspace_id = conversations.workspace_id)))
  WHERE ((conversations.id = conversation_tags.conversation_id) AND (user_workspaces.user_id = auth.uid())))));


--
-- Name: quick_replies Users can view quick replies for their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view quick replies for their workspaces" ON public.quick_replies FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = quick_replies.workspace_id) AND (user_workspaces.user_id = auth.uid())))));


--
-- Name: routing_config Users can view routing config for their workspace; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view routing config for their workspace" ON public.routing_config FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = routing_config.workspace_id) AND (user_workspaces.user_id = auth.uid())))));


--
-- Name: tags Users can view tags for their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view tags for their workspaces" ON public.tags FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_workspaces
  WHERE ((user_workspaces.workspace_id = tags.workspace_id) AND (user_workspaces.user_id = auth.uid())))));


--
-- Name: message_templates Users can view templates of their workspaces; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Users can view templates of their workspaces" ON public.message_templates FOR SELECT USING ((workspace_id IN ( SELECT user_workspaces.workspace_id
   FROM public.user_workspaces
  WHERE (user_workspaces.user_id = auth.uid()))));


--
-- Name: conversation_tags; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.conversation_tags ENABLE ROW LEVEL SECURITY;

--
-- Name: media_files; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.media_files ENABLE ROW LEVEL SECURITY;

--
-- Name: message_templates; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.message_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: quick_replies; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.quick_replies ENABLE ROW LEVEL SECURITY;

--
-- Name: routing_config; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.routing_config ENABLE ROW LEVEL SECURITY;

--
-- Name: tags; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.tags ENABLE ROW LEVEL SECURITY;

--
-- Name: whatsapp_sessions; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.whatsapp_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO service_role;


--
-- Name: FUNCTION handle_new_user(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.handle_new_user() TO anon;
GRANT ALL ON FUNCTION public.handle_new_user() TO authenticated;
GRANT ALL ON FUNCTION public.handle_new_user() TO service_role;


--
-- Name: TABLE channels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.channels TO anon;
GRANT ALL ON TABLE public.channels TO authenticated;
GRANT ALL ON TABLE public.channels TO service_role;


--
-- Name: TABLE contacts; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.contacts TO anon;
GRANT ALL ON TABLE public.contacts TO authenticated;
GRANT ALL ON TABLE public.contacts TO service_role;


--
-- Name: TABLE conversation_tags; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversation_tags TO anon;
GRANT ALL ON TABLE public.conversation_tags TO authenticated;
GRANT ALL ON TABLE public.conversation_tags TO service_role;


--
-- Name: TABLE conversations; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.conversations TO anon;
GRANT ALL ON TABLE public.conversations TO authenticated;
GRANT ALL ON TABLE public.conversations TO service_role;


--
-- Name: TABLE crm_cards; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_cards TO anon;
GRANT ALL ON TABLE public.crm_cards TO authenticated;
GRANT ALL ON TABLE public.crm_cards TO service_role;


--
-- Name: TABLE crm_funnels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_funnels TO anon;
GRANT ALL ON TABLE public.crm_funnels TO authenticated;
GRANT ALL ON TABLE public.crm_funnels TO service_role;


--
-- Name: TABLE crm_stages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.crm_stages TO anon;
GRANT ALL ON TABLE public.crm_stages TO authenticated;
GRANT ALL ON TABLE public.crm_stages TO service_role;


--
-- Name: TABLE media_files; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.media_files TO anon;
GRANT ALL ON TABLE public.media_files TO authenticated;
GRANT ALL ON TABLE public.media_files TO service_role;


--
-- Name: TABLE message_templates; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.message_templates TO anon;
GRANT ALL ON TABLE public.message_templates TO authenticated;
GRANT ALL ON TABLE public.message_templates TO service_role;


--
-- Name: TABLE messages; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.messages TO anon;
GRANT ALL ON TABLE public.messages TO authenticated;
GRANT ALL ON TABLE public.messages TO service_role;


--
-- Name: TABLE profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.profiles TO anon;
GRANT ALL ON TABLE public.profiles TO authenticated;
GRANT ALL ON TABLE public.profiles TO service_role;


--
-- Name: TABLE quick_replies; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.quick_replies TO anon;
GRANT ALL ON TABLE public.quick_replies TO authenticated;
GRANT ALL ON TABLE public.quick_replies TO service_role;


--
-- Name: TABLE routing_config; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.routing_config TO anon;
GRANT ALL ON TABLE public.routing_config TO authenticated;
GRANT ALL ON TABLE public.routing_config TO service_role;


--
-- Name: TABLE tags; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tags TO anon;
GRANT ALL ON TABLE public.tags TO authenticated;
GRANT ALL ON TABLE public.tags TO service_role;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.tenants TO anon;
GRANT ALL ON TABLE public.tenants TO authenticated;
GRANT ALL ON TABLE public.tenants TO service_role;


--
-- Name: TABLE user_workspaces; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.user_workspaces TO anon;
GRANT ALL ON TABLE public.user_workspaces TO authenticated;
GRANT ALL ON TABLE public.user_workspaces TO service_role;


--
-- Name: TABLE whatsapp_sessions; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.whatsapp_sessions TO anon;
GRANT ALL ON TABLE public.whatsapp_sessions TO authenticated;
GRANT ALL ON TABLE public.whatsapp_sessions TO service_role;


--
-- Name: TABLE workspaces; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.workspaces TO anon;
GRANT ALL ON TABLE public.workspaces TO authenticated;
GRANT ALL ON TABLE public.workspaces TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON FUNCTIONS TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO postgres;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO anon;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO authenticated;
ALTER DEFAULT PRIVILEGES FOR ROLE supabase_admin IN SCHEMA public GRANT ALL ON TABLES TO service_role;


--
-- PostgreSQL database dump complete
--

\unrestrict umwSdpl2RxdTJwZEwlWEHpqJVrmg6CxYd5eOHagXKGHTEy5zjIcMXEd88RUvrDy

